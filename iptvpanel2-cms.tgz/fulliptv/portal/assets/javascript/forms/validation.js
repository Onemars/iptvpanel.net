/*! ========================================================================
 * validation.js
 * Page/renders: forms-validation.html
 * Plugins used: selectize, parsley
 * ======================================================================== */
$(function () {
    // custom select
    // ================================
    $("select").selectize();
});