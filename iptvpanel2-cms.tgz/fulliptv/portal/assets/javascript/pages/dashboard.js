/*! ========================================================================
 * dashboard.js
 * Page/renders: index.html
 * Plugins used: flot, sparkline, selectize
 * ======================================================================== */
$(function () {
    // Selectize
    // ================================
    (function () {
        $("#selectize-customselect").selectize();
    })();
     
    // Sparkline
    // ================================
    (function () {
        $(".sparklines").sparkline("html", {
            enableTagOptions: true
        });
    })();
    
});
